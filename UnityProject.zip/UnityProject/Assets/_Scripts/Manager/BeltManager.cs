using UnityEngine;

public class BeltManager : MonoBehaviour
{
    public float speed = 2f;
}
