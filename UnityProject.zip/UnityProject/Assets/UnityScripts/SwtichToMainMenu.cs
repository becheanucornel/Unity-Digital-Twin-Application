using UnityEngine;
using UnityEngine.SceneManagement;

public class SwtichToMainMenu : MonoBehaviour
{

    public string scene;

    // Function to switch to Scene
    public void SwitchToScene()
    {
        if (SceneManager.GetActiveScene().name != scene)
        {
            SceneManager.LoadScene(scene);
        }
    }
}
