using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraPlayer : MonoBehaviour
{
    public float moveSpeed = 5f; // Speed at which the camera moves
    public float rotationSpeed = 100000f; // Speed at which the camera rotates
    public float verticalMoveSpeed = 100f; // Speed for vertical movement

    void Update()
    {
        // Get input from WASD keys
        float moveHorizontal = Input.GetAxis("Horizontal"); // A/D or Left/Right arrow keys
        float moveVertical = Input.GetAxis("Vertical");   // W/S or Up/Down arrow keys

        // Calculate movement direction relative to the camera's orientation
        Vector3 movement = transform.right * moveHorizontal + transform.forward * moveVertical;

        // Add vertical movement using Shift (up) and Ctrl (down)
        if (Input.GetKey(KeyCode.LeftShift))
        {
            movement.y += verticalMoveSpeed * Time.deltaTime;
        }
        if (Input.GetKey(KeyCode.LeftControl))
        {
            movement.y -= verticalMoveSpeed * Time.deltaTime;
        }

        // Apply movement to the camera
        transform.position += movement * moveSpeed * Time.deltaTime;

        // Get input from mouse for rotation
        float rotateHorizontal = Input.GetAxis("Mouse X"); // Mouse movement left/right
        float rotateVertical = Input.GetAxis("Mouse Y");   // Mouse movement up/down

        // Apply rotation to the camera
        transform.Rotate(Vector3.up, rotateHorizontal * rotationSpeed * Time.deltaTime, Space.World);
        transform.Rotate(Vector3.left, rotateVertical * rotationSpeed * Time.deltaTime, Space.Self);
    }
}
