using System.ComponentModel;
using UnityEngine;

public class PauseMenu: MonoBehaviour
{
    public GameObject pauseMenuUI; // Assign the PauseMenu canvas in the Inspector.
    public static bool isPaused = false;
    public Camera targetCamera; // Assign your camera in the inspector
    private int currentDisplayIndex = 0;

    void Start()
    {
        Resume();
        for (int i = 0; i < Display.displays.Length; i++)
        {
            if (!Display.displays[i].active)
            {
                Display.displays[i].Activate();
            }
        }

        // Ensure the camera starts on the current display
        UpdateCameraDisplay();
    }
    void Update()
    {
        // Check if the ESC key is pressed
        if (Input.GetKeyDown(KeyCode.Escape))
        {
            if (isPaused)
                Resume();
            else
                Pause();
        }
    }

    public void Resume()
    {
        pauseMenuUI.SetActive(false); // Disable the pause menu UI
        Time.timeScale = 1f; // Resume game time
        isPaused = false;

        // Re-enable player movement or input
        Cursor.lockState = CursorLockMode.Locked;
        Cursor.visible = false;
    }

    void Pause()
    {
        pauseMenuUI.SetActive(true); // Enable the pause menu UI
        Time.timeScale = 0f; // Stop game time
        isPaused = true;

        // Disable player movement or input
        Cursor.lockState = CursorLockMode.None;
        Cursor.visible = true;
    }

    public void QuitGame()
    {
        Debug.Log("Quitting Game...");
        Application.Quit();
    }

    public void ChangeDisplay_UP()
    {
        currentDisplayIndex = (currentDisplayIndex + 1) % Display.displays.Length;
        UpdateCameraDisplay();
    }

    public void ChangeDisplay_DOWN()
    {
        currentDisplayIndex = (currentDisplayIndex - 1 + Display.displays.Length) % Display.displays.Length;
        UpdateCameraDisplay();
    }

    private void UpdateCameraDisplay()
    {
        if (targetCamera != null)
        {
            targetCamera.targetDisplay = currentDisplayIndex;
            Debug.Log($"Camera is now rendering to display {currentDisplayIndex}.");
        }
        else
        {
            Debug.LogError("No camera assigned to DisplayToggle.");
        }
    }
}
