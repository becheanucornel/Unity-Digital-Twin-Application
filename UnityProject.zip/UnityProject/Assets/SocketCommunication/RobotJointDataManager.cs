using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using UnityEngine;

public class RobotJointDataManager : MonoBehaviour
{
    private TcpListener posListener;
    private TcpListener gripperListener;
    private TcpClient posClient;
    private TcpClient gripperClient;
    private NetworkStream posStream;
    private NetworkStream gripperStream;
    private byte[] posReceivedBuffer = new byte[1024];
    private byte[] gripperReceivedBuffer = new byte[1024];
    private string posReceivedData = "";
    private string gripperReceivedData = "";
    private const int posPort = 5000;
    private const int gripperPort = 5001;
    private const string robotStudioIp = "127.0.0.1";  // Local IP address

    private bool start = false;
    private bool startExecuted = false;

    public float joint1Angle;
    public float joint2Angle;
    public float joint3Angle;
    public float joint4Angle;
    public float joint5Angle;
    public float joint6Angle;

    private Vector3 joint1AnchorPosition = new Vector3(0, 0.2f, 0);
    private Quaternion joint1AnchorRotation = Quaternion.Euler(0, 0, 270);
    private Vector3 joint2AnchorPosition = new Vector3(0, 0.4f, 0);
    private Quaternion joint2AnchorRotation = Quaternion.Euler(0, 0, 0);
    private Vector3 joint3AnchorPosition = new Vector3(0, 0.88f, 0);
    private Quaternion joint3AnchorRotation = Quaternion.Euler(0, 0, 0);
    private Vector3 joint4AnchorPosition = new Vector3(0, 0.88f, 0.3f);
    private Quaternion joint4AnchorRotation = Quaternion.Euler(0, 90, 0);
    private Vector3 joint5AnchorPosition = new Vector3(0, 0.88f, 0.44f);
    private Quaternion joint5AnchorRotation = Quaternion.Euler(0, 0, 0);
    private Vector3 joint6AnchorPosition = new Vector3(0, 0.88f, 0.52f);
    private Quaternion joint6AnchorRotation = Quaternion.Euler(0, 90, 0);
    private Vector3 gripper1AnchorPosition = new Vector3(0, 0.93f, 0.65f);
    private Quaternion gripper1AnchorRotation = Quaternion.Euler(0, 0, 270);
    private Vector3 gripper2AnchorPosition = new Vector3(0, 0.84f, 0.65f);
    private Quaternion gripper2AnchorRotation = Quaternion.Euler(0, 0, 90);

    [SerializeField] public ArticulationBody World;
    [SerializeField] public ArticulationBody RobotJoint1;
    [SerializeField] public ArticulationBody RobotJoint2;
    [SerializeField] public ArticulationBody RobotJoint3;
    [SerializeField] public ArticulationBody RobotJoint4;
    [SerializeField] public ArticulationBody RobotJoint5;
    [SerializeField] public ArticulationBody RobotJoint6;
    [SerializeField] public ArticulationBody RobotGripper1;
    [SerializeField] public ArticulationBody RobotGripper2;

    void Start()
    {
        try
        {
            startExecuted = false;
            World.immovable = true;

            SetAnchors();

            if (start && !startExecuted)
            {
                StartProcess();
            }
        }
        catch (Exception ex)
        {
            Debug.LogError("Error in Start method: " + ex.Message);
        }
    }

    void Update()
    {
        try
        {
            if (start && !startExecuted)
            {
                StartProcess();
                UpdateProcess();
            }
            else
            {
                UpdateProcess();
            }
        }
        catch (Exception ex)
        {
            Debug.LogError("Error in Update: " + ex.Message);
        }
    }

    private void StartProcess()
    {
        try
        {
            posListener = new TcpListener(IPAddress.Parse(robotStudioIp), posPort);
            gripperListener = new TcpListener(IPAddress.Parse(robotStudioIp), gripperPort);

            posListener.Start();
            gripperListener.Start();

            Debug.Log("Listening for connection...");

            posClient = posListener.AcceptTcpClient();
            gripperClient = gripperListener.AcceptTcpClient();

            posStream = posClient.GetStream();
            gripperStream = gripperClient.GetStream();

            Debug.Log("Connection established.");
            startExecuted = true;
        }
        catch (Exception ex)
        {
            Debug.LogError("Error starting listeners: " + ex.Message);
        }
    }

    private void UpdateProcess()
    {
        try
        {
            if (posStream != null && posStream.DataAvailable)
            {
                int bytesRead = posStream.Read(posReceivedBuffer, 0, posReceivedBuffer.Length);
                if (bytesRead > 0)
                {
                    posReceivedData += Encoding.ASCII.GetString(posReceivedBuffer, 0, bytesRead);
                    if (posReceivedData.Contains(","))
                    {
                        ProcessPosReceivedData(posReceivedData.Trim());
                        posReceivedData = "";
                    }
                }
            }

            if (gripperStream != null && gripperStream.DataAvailable)
            {
                int bytesRead = gripperStream.Read(gripperReceivedBuffer, 0, gripperReceivedBuffer.Length);
                if (bytesRead > 0)
                {
                    gripperReceivedData += Encoding.ASCII.GetString(gripperReceivedBuffer, 0, bytesRead);
                    ProcessGripperReceivedData(gripperReceivedData.Trim());
                    gripperReceivedData = "";
                }
            }
        }
        catch (Exception ex)
        {
            Debug.LogError("Error in UpdateProcess: " + ex.Message);
        }
    }

    private void SetAnchors()
    {
        RobotJoint1.anchorPosition = joint1AnchorPosition;
        RobotJoint2.anchorPosition = joint2AnchorPosition;
        RobotJoint3.anchorPosition = joint3AnchorPosition;
        RobotJoint4.anchorPosition = joint4AnchorPosition;
        RobotJoint5.anchorPosition = joint5AnchorPosition;
        RobotJoint6.anchorPosition = joint6AnchorPosition;
        RobotGripper1.anchorPosition = gripper1AnchorPosition;
        RobotGripper2.anchorPosition = gripper2AnchorPosition;

        RobotJoint1.anchorRotation = joint1AnchorRotation;
        RobotJoint2.anchorRotation = joint2AnchorRotation;
        RobotJoint3.anchorRotation = joint3AnchorRotation;
        RobotJoint4.anchorRotation = joint4AnchorRotation;
        RobotJoint5.anchorRotation = joint5AnchorRotation;
        RobotJoint6.anchorRotation = joint6AnchorRotation;
        RobotGripper1.anchorRotation = gripper1AnchorRotation;
        RobotGripper2.anchorRotation = gripper2AnchorRotation;
    }

    private void ProcessPosReceivedData(string data)
    {
        string[] jointValues = data.Split(',');

        if (jointValues.Length == 6)
        {
            joint1Angle = float.Parse(jointValues[0]);
            joint2Angle = float.Parse(jointValues[1]);
            joint3Angle = float.Parse(jointValues[2]);
            joint4Angle = float.Parse(jointValues[3]);
            joint5Angle = float.Parse(jointValues[4]);
            joint6Angle = float.Parse(jointValues[5]);

            SetJointAngles();
        }
        else
        {
            Debug.LogWarning("Received data does not match expected number of joint values.");
        }
    }

    private void ProcessGripperReceivedData(string data)
    {
        if (data == "true")
        {
            ArticulationDrive driveGripper1 = RobotGripper1.xDrive;
            ArticulationDrive driveGripper2 = RobotGripper2.xDrive;
            driveGripper1.target = 0.009f;
            driveGripper2.target = 0.009f;
            RobotGripper1.xDrive = driveGripper1;
            RobotGripper2.xDrive = driveGripper2;
        }
        else
        {
            ArticulationDrive driveGripper1 = RobotGripper1.xDrive;
            ArticulationDrive driveGripper2 = RobotGripper2.xDrive;
            driveGripper1.target = 0f;
            driveGripper2.target = 0f;
            RobotGripper1.xDrive = driveGripper1;
            RobotGripper2.xDrive = driveGripper2;
        }
    }

private void SetJointAngles()
{
    // Initialize the drive variables by copying the existing xDrive of each joint
    ArticulationDrive driveJoint1 = RobotJoint1.xDrive;
    ArticulationDrive driveJoint2 = RobotJoint2.xDrive;
    ArticulationDrive driveJoint3 = RobotJoint3.xDrive;
    ArticulationDrive driveJoint4 = RobotJoint4.xDrive;
    ArticulationDrive driveJoint5 = RobotJoint5.xDrive;
    ArticulationDrive driveJoint6 = RobotJoint6.xDrive;

    // Set the target angles for each joint
    driveJoint1.target = joint1Angle;
    driveJoint2.target = joint2Angle;
    driveJoint3.target = joint3Angle;
    driveJoint4.target = joint4Angle;
    driveJoint5.target = joint5Angle;
    driveJoint6.target = joint6Angle;

    // Apply the updated drive settings back to each joint
    RobotJoint1.xDrive = driveJoint1;
    RobotJoint2.xDrive = driveJoint2;
    RobotJoint3.xDrive = driveJoint3;
    RobotJoint4.xDrive = driveJoint4;
    RobotJoint5.xDrive = driveJoint5;
    RobotJoint6.xDrive = driveJoint6;
}

    public void StartCommunication()
    {
        start = true;
    }

    public void StopCommunication()
    {
        start = false;
        startExecuted = false;

        try
        {
            posStream?.Close();
            posClient?.Close();
            posListener?.Stop();

            gripperStream?.Close();
            gripperClient?.Close();
            gripperListener?.Stop();
        }
        catch (Exception ex)
        {
            Debug.LogError("Error stopping communication: " + ex.Message);
        }
    }

    void OnApplicationQuit()
    {
        try
        {
            posStream?.Close();
            posClient?.Close();
            posListener?.Stop();

            gripperStream?.Close();
            gripperClient?.Close();
            gripperListener?.Stop();
        }
        catch (Exception ex)
        {
            Debug.LogError("Error during application quit: " + ex.Message);
        }
    }
}
